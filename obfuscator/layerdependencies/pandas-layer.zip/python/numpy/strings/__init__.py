from numpy._core.strings import __all__, __doc__
from numpy._core.strings import *
